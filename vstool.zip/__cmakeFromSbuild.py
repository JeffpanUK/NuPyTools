#!/usr/bin/python
import os
import sys

tgtPath = {'console_static_exe':'rsautomotive/applications/console/src'}


# Remove empty space from the lines.
def removeEmptySpace(lines):
    cleanedUpLines = []
    for line in lines:
        line = line.rstrip("\r\n")
        line = line.lstrip(" \t")
        cleanedUpLines.append(line)
    return cleanedUpLines


# We are only interested in the lines which start with:
#   "Sources for "  : gives us the name of the components (srcs.txt)
#   "Includes for " : gives us the name of the components (incs.txt)
#   "Includes for " : gives us the name of the components (defs.txt)
#   "/"             : path to a C file [TODO: check windows compatibility]
def filterSrcsLines(srcs):
    cleanedUpLines = []
    for src in srcs:
        if "Sources for " in src:
            cleanedUpLines.append(src)
        if "Includes for " in src:
            cleanedUpLines.append(src)
        if "Defines for " in src:
            cleanedUpLines.append(src)
        if "/" in src:
            cleanedUpLines.append(src)
        if "\\" in src:
            cleanedUpLines.append(src)
    return cleanedUpLines


# for ('SBUILD_CCPP_TGTPLATFORM', 'darwin_x86_64') kind
# of input
def postProcessDefine(define):
    if "(" in define:
        define = define.translate(None, "()'")
        define = define.split(", ")
        define = define[0] + "=" + define[1]
    return define


def findProjectName(srcsLines):
    projectName = "Project Name not found"
    found = False
    for idx in range(0, len(srcsLines)):
        if "sbuild: The root target of the SBuild tree is:" in srcsLines[idx]:
            found = True
            break
    if found == True:
        projectName = (srcsLines[idx + 1])[9:]  # Filter out the root target name
    return projectName


# Return the lines (sources, inc paths or defines) that
# correspond to a component
def findLinesFromAComponent(component, lines):
    componentLines = []
    found = False
    for idx in range(0, len(lines)):
        if lines[idx] == "":
            found = False
        if found == True:
            if ("Sources for " in lines[idx]) or ("Includes for " in lines[idx]) or ("Defines for " in lines[idx]) :
                found = False
            else:
                componentLines.append(lines[idx])
        if " " + component in lines[idx]:
            found = True
    return componentLines


# For source code we want to be sure to only get files that
# we want to compile and not e.g. XML files as defined in
# the realspeaklogstrings_h component
def findSourceCodeLinesFromAComponent(component, lines):
    componentSourceCodeLines = []
    componentLines = findLinesFromAComponent(component, lines)
    for componentLine in componentLines:
        if ".c" in componentLine:
            componentSourceCodeLines.append(componentLine)
    return componentSourceCodeLines


def findRootDirFromAComponent(componentSources):
    rootDir = ""
    if len(componentSources) == 1:
        rootDir = os.path.dirname(componentSources[0])
    else:
        commonPrefix = os.path.commonprefix(componentSources)
        # Make it a valid path
        rootDir = os.path.split(commonPrefix)[0]

    # Remove the src directory if present
    path, tail = os.path.split(rootDir)
    if tail == "src":
        rootDir = path
    return rootDir


###
# MAIN
###

theComponents = []
cFlags = []

###
# Pass 1 : Load all lines as generated for the srcs, inc and def SBuild builds:
###

# The srcs file gives us all the paths to the required source files for a certain component
srcs = open("./srcs.txt", "r").readlines()
srcs = removeEmptySpace(srcs)

# The incs file gives us all the paths to the required include files for a certain component
incs = open("./incs.txt", "r").readlines()
incs = removeEmptySpace(incs)
# incs = filterSrcsLines(incs)

# The defs file gives us all the paths to the required defines for a certain component
defs = open("./defs.txt", "r").readlines()
defs = removeEmptySpace(defs)
# defs = filterSrcsLines(defs)

# The func file gives us all the functions contained in a Csource file. Unfortunately, it
# doesn't know about #ifdef and will return all potential functions that can be compiled in.
func = open("./func.txt", "r").readlines()
func = removeEmptySpace(func)
# func = filterSrcsLines(func)

###
# Pass 2 : Find the project name:
###
projectName = findProjectName(srcs)


###
# Pass 3 : Find all components that we might have to build:
###
srcs = filterSrcsLines(srcs)
for src in srcs:
    if "Sources for " in src:
        if src[12:] not in theComponents:
            theComponents.append(src[12:])  # Chop of "Sources for " part

###
# Pass 4 : determine the sources, inc paths and defines for every component
###
subProjects = []
emptySubProject = []
for component in theComponents:
    found            = False
    componentSources = []
    includePaths     = []
    defines          = []
    componentSources = findSourceCodeLinesFromAComponent(component, srcs)
    if len(componentSources) == 0:
        emptySubProject.append(component)
    else:
        rootDir = findRootDirFromAComponent(componentSources)
        includePaths = findLinesFromAComponent(component, incs)
        defines      = findLinesFromAComponent(component, defs)
        aSubProject  = (component, rootDir, componentSources, includePaths, defines)
        subProjects.append(aSubProject)

###
# Pass 5 : Find the object which contains the main function:
###
if projectName not in tgtPath:
    print "Please set a target path for %s" % projectName
    assert(False)

tgtstr = tgtPath[projectName]
tgtstr = "-".join(tgtstr.split("/"))
print tgtstr
idx = 0
while idx < len(func):
    if len(func[idx].strip()) == 0:
        idx = idx + 1
        continue

    if "int main" in func[idx]:
        print func[idx]
        idy = idx
        while "File:" not in func[idy]:
            idy = idy - 1

        mainSourceFile = func[idy][7:]
        mainstr = "-".join(mainSourceFile.split("\\"))
        if mainstr.count(tgtstr) > 0:
            print "Got", mainSourceFile
            break
        else:
            mainSourceFile = None
            idx = idx + 1
    else:
        idx = idx + 1


# Now figure out in which subproject the main entry point is located
found = False
idx = 0
while idx < len(subProjects):
    for sourceFile in subProjects[idx][2]:
        if mainSourceFile.rstrip(" \r\n") == sourceFile.rstrip(" \r\n"):
            found = True
            break
    if found == False:
        idx = idx + 1
    else:
        break
print "The", subProjects[idx][0], "seems to contain the main function."

mainProject = subProjects[idx]
del subProjects[idx]              # And remove mainProject from the subprojects

# mainProject = subProjects[-1]   # Gambling that the last object will always contain the source with the main() function.
# subProjects.pop()               # And remove it from the subprojects

print
print "Nothing to build for:"
for anEmptySubProject in emptySubProject:
    print "  " + anEmptySubProject
print

###
# Pass 5 : Build the subproject CMakeList files
###
print "Generating the CMakeList.txt files."
if not os.path.exists("./CMakeLists/"):
    os.makedirs("./CMakeLists/")

subProjectNames = []


for subProject in subProjects:
    subProjectName     = subProject[0]
    subProjectRootDir  = subProject[1]
    subProjectSources  = subProject[2]
    subProjectIncPaths = subProject[3]
    subProjectDefines  = subProject[4]

    subProjectSRCName = subProjectName + "_SRCS"
    subProjectINCName = subProjectName + "_INC"
    subProjectDEFName = subProjectName + "_DEF"
    subProjectNames.append(subProjectName)

    if not os.path.exists("./CMakeLists/" + subProjectName):
        os.makedirs("./CMakeLists/" + subProjectName)

    CMakeFile = open("./CMakeLists/" + subProjectName + "/CmakeLists.txt", "w")

    CMakeFile.write("CMAKE_MINIMUM_REQUIRED(VERSION 2.6)\n")
    CMakeFile.write("\n")
    CMakeFile.write("project( " + subProjectName + " )\n")
    CMakeFile.write("\n")
    CMakeFile.write("set(CMAKE_VERBOSE_MAKEFILE on)\n")
    CMakeFile.write("\n")

    CMakeFile.write("set(cmake_cxx_flags\n")
    for cFlag in cFlags:
        CMakeFile.write("        " + cFlag + "\n")
    CMakeFile.write("   )\n")
    CMakeFile.write("\n")

    CMakeFile.write("set(" + subProjectSRCName + "\n")
    for srcFile in subProjectSources:
        CMakeFile.write("        " + srcFile + "\n")
    CMakeFile.write("   )\n")
    CMakeFile.write("\n")
    CMakeFile.write("set(" + subProjectINCName + "\n")
    for incPath in subProjectIncPaths:
        CMakeFile.write("        " + incPath + "\n")
    CMakeFile.write("   )\n")
    CMakeFile.write("\n")
    CMakeFile.write("set(" + subProjectDEFName + "\n")
    for define in subProjectDefines:
        define = postProcessDefine(define)
        CMakeFile.write("        -D" + define + "\n")
    CMakeFile.write("   )\n")
    CMakeFile.write("\n")
    CMakeFile.write("include_directories( ${" + subProjectINCName + "})\n")
    CMakeFile.write("add_definitions( ${" + subProjectDEFName + "})\n")
    CMakeFile.write("add_library( " + subProjectName + " ${" + subProjectSRCName + "} )\n")
    CMakeFile.write("\n")
    CMakeFile.write("add_definitions( ${cmake_cxx_flags})\n")
    CMakeFile.close()

###
# Pass 6 : Build the master CMakeList file
###
print "Generating master CMakeList.txt file"

mainProjectName     = mainProject[0]
mainProjectRootDir  = mainProject[1]
mainProjectSources  = mainProject[2]
mainProjectIncPaths = mainProject[3]
mainProjectDefines  = mainProject[4]

mainProjectSRCName = mainProjectName + "_SRCS"
mainProjectINCName = mainProjectName + "_INC"
mainProjectDEFName = mainProjectName + "_DEF"

CMakeFile = open("CmakeLists.txt", "w")
CMakeFile.write("CMAKE_MINIMUM_REQUIRED(VERSION 2.6)\n")
CMakeFile.write("\n")
CMakeFile.write("project( " + projectName + " )\n")
CMakeFile.write("\n")
CMakeFile.write("set(CMAKE_VERBOSE_MAKEFILE on)\n")
CMakeFile.write("\n")

CMakeFile.write("set(cmake_cxx_flags\n")
for cFlag in cFlags:
    CMakeFile.write("        " + cFlag + "\n")
CMakeFile.write("   )\n")
CMakeFile.write("\n")

CMakeFile.write("\n")
CMakeFile.write("set(" + mainProjectSRCName + "\n")
for srcFile in mainProjectSources:
    CMakeFile.write("        " + srcFile + "\n")
CMakeFile.write("   )\n")
CMakeFile.write("\n")
CMakeFile.write("set(" + mainProjectINCName + "\n")
for incPath in mainProjectIncPaths:
    CMakeFile.write("        " + incPath + "\n")
CMakeFile.write("   )\n")
CMakeFile.write("\n")
CMakeFile.write("set(" + mainProjectDEFName + "\n")
for define in mainProjectDefines:
    define = postProcessDefine(define)
    CMakeFile.write("        -D" + define + "\n")
CMakeFile.write("   )\n")
CMakeFile.write("\n")

for subProject in subProjects:
    subProjectName = subProject[0]
    CMakeFile.write("add_subdirectory(./CMakeLists/" + subProjectName + ")\n")

CMakeFile.write("\n")
CMakeFile.write("include_directories( ${" + mainProjectINCName + "})\n")
CMakeFile.write("add_definitions( ${" + mainProjectDEFName + "})\n")
CMakeFile.write("\n")
CMakeFile.write("add_definitions( ${cmake_cxx_flags})\n")
CMakeFile.write("\n")
CMakeFile.write("add_executable( " + projectName + " ${" + mainProjectSRCName + "} )\n")
CMakeFile.write("\n")

for subProject in subProjects:
    subProjectName = subProject[0]
    CMakeFile.write("target_link_libraries( " + projectName + " " + subProjectName + ")\n")

CMakeFile.close()
